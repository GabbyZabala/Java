public class ZabalaAct9 {
    public static SquareZabala9 sb = new SquareZabala9();

    public static void main(String[] args) {
        sb.Area();
        sb.Perameters();
        sb.displayType(); 
    }
}
